package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChatViewModel
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeuralViolet
import com.example.ui.theme.ObsidianBlack
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun VoiceScreen(
    viewModel: ChatViewModel,
    innerPadding: PaddingValues
) {
    val coroutineScope = rememberCoroutineScope()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val messages by viewModel.messagesState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()

    // Simulate standard voice detection activity
    var isListening by remember { mutableStateOf(false) }
    var mockWaveAmplitude by remember { mutableStateOf(0.1f) }

    // Floating neural pulsing transitions
    val infiniteTransition = rememberInfiniteTransition(label = "VoicePulse")
    
    val outerScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isSpeaking || isListening) 1.6f else 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OuterPulse"
    )

    val innerScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isSpeaking || isListening) 1.3f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "InnerPulse"
    )

    // Generate random wave amplitudes during voice mode to feel realistic
    LaunchedEffect(isListening, isSpeaking) {
        if (isListening || isSpeaking) {
            while (true) {
                mockWaveAmplitude = kotlin.random.Random.Default.nextFloat() * 0.7f + 0.2f
                delay(120)
            }
        } else {
            mockWaveAmplitude = 0.05f
        }
    }

    val lastAiResponse = remember(messages) {
        messages.lastOrNull { it.sender == "ai" }?.text ?: "Hello! I am M.Q.Live voice guide. Tap the mic to begin speaking."
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ObsidianBlack, Color(0xFF1E1E2F))
                )
            )
            .padding(innerPadding),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Text(
                    text = "M.Q.Live Voice Assistant",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyan
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Vocal AI Engine | گوینده صوتی هوشمند",
                    fontSize = 12.sp,
                    color = NeuralViolet,
                    fontWeight = FontWeight.Medium
                )
            }

            // Pulsing Neural Wave Core (Luxury UI centerpiece)
            Box(
                modifier = Modifier
                    .size(240.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Wave Layer 2
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .scale(outerScale)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(NeonCyan.copy(alpha = 0.15f), Color.Transparent)
                            ),
                            CircleShape
                        )
                )

                // Inner Wave Layer 1
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .scale(innerScale)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(NeuralViolet.copy(alpha = 0.2f), Color.Transparent)
                            ),
                            CircleShape
                        )
                )

                // Core glowing orb
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .shadow(24.dp, CircleShape, spotColor = NeonCyan)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(NeonCyan, NeuralViolet)
                            ),
                            CircleShape
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                        .clickable {
                            if (isSpeaking) {
                                viewModel.stopSpeaking()
                            } else {
                                isListening = !isListening
                                if (isListening) {
                                    // Simulated user speech triggering response after 3 seconds
                                    isListening = true
                                    coroutineScope.launch {
                                        delay(3000)
                                        if (isListening) {
                                            isListening = false
                                            viewModel.sendMessage("سلام، لطفا یک شعر کوتاه یا معرفی صوتی بگو")
                                        }
                                    }
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSpeaking) {
                            Icons.Default.Stop
                        } else if (isListening) {
                            Icons.Default.MicNone
                        } else {
                            Icons.Default.Mic
                        },
                        contentDescription = "Voice controls",
                        tint = ObsidianBlack,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            // Real-time voice amplitude spectrum visualizer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp)
                    .padding(horizontal = 40.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(12) { index ->
                    val factor = if (index % 2 == 0) 1.5f else 0.8f
                    val heightRatio = (mockWaveAmplitude * factor).coerceIn(0.1f, 1.0f)
                    Box(
                        modifier = Modifier
                            .width(6.dp)
                            .fillMaxHeight(heightRatio)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(NeonCyan, NeuralViolet)
                                ),
                                RoundedCornerShape(3.dp)
                            )
                    )
                }
            }

            // Live Glassmorphic Subtitles box
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White.copy(alpha = 0.05f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 100.dp, max = 150.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (isListening) "Listening carefully to your voice... / در حال شنیدن صدای شما..." 
                               else if (isGenerating) "Generating vocal answer... / در حال ساخت پاسخ صوتی..."
                               else if (isSpeaking) "M.Q.Live is speaking... / در حال صحبت..."
                               else "Voice Engine Standby / آماده دریافت صحبت صوتی",
                        fontSize = 11.sp,
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = lastAiResponse,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        maxLines = 4
                    )
                }
            }

            // Control Actions Panel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Speaker mute toggle button
                IconButton(
                    onClick = {
                        viewModel.updateSettings { it.copy(isVoiceEnabled = !it.isVoiceEnabled) }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color.White.copy(alpha = 0.08f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (settings.isVoiceEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "Speaker status",
                        tint = if (settings.isVoiceEnabled) NeonCyan else Color.White
                    )
                }

                // Simulation trigger button to talk to the AI easily
                Button(
                    onClick = {
                        viewModel.sendMessage("Hello M.Q.Live! Let's talk about artificial intelligence offline.")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeuralViolet),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text("Trigger Voice / صحبت تستی")
                }

                // TTS Voice Picker button
                IconButton(
                    onClick = {
                        viewModel.speakText("Hi, I am M.Q.Live. Your luxury speaking voice assistant.")
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color.White.copy(alpha = 0.08f), CircleShape)
                ) {
                    Icon(
                        Icons.Default.RecordVoiceOver,
                        contentDescription = "Voice Select",
                        tint = NeonCyan
                    )
                }
            }
        }
    }
}
