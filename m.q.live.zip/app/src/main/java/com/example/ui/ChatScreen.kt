package com.example.ui

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.AppSettings
import com.example.data.ChatViewModel
import com.example.data.Message
import com.example.ui.theme.CyberSlate
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeuralViolet
import com.example.ui.theme.ObsidianBlack
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    innerPadding: PaddingValues,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val messages by viewModel.messagesState.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val generationChunk by viewModel.generationChunk.collectAsState()
    val selectedImageUri by viewModel.selectedImageUri.collectAsState()
    val settings by viewModel.settingsState.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val lazyListState = rememberLazyListState()

    // Activity launcher for choosing an image
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        viewModel.selectImageUri(uri)
    }

    // Line-by-Line Copy Mode dialog state
    var lineCopyMessage by remember { mutableStateOf<Message?>(null) }

    // Scroll to bottom when new messages arrive
    LaunchedEffect(messages.size, generationChunk) {
        if (messages.isNotEmpty()) {
            lazyListState.animateScrollToItem(messages.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(innerPadding)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Workspace Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onOpenDrawer) {
                    Icon(
                        Icons.Default.Menu,
                        contentDescription = "Sessions Menu",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                // Header Branding Info
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "M.Q.Live Workspace",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = when (settings.activeModelType) {
                            "gemini" -> "Gemini Core Engine"
                            "groq" -> "Groq Ultra Speed"
                            else -> "Offline Local GGUF"
                        },
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                IconButton(onClick = { viewModel.createNewSession("New Chat Workspace") }) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "New Session",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))

            // Message Board
            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (messages.isEmpty() && !isGenerating) {
                    item {
                        EmptyStateWidget(settings)
                    }
                } else {
                    items(messages) { message ->
                        MessageBubble(
                            message = message,
                            onLineCopyTriggered = { lineCopyMessage = it }
                        )
                    }

                    // Dynamic streaming chunk display
                    if (isGenerating && generationChunk.isNotEmpty()) {
                        item {
                            MessageBubble(
                                message = Message(
                                    sessionId = "",
                                    sender = "ai",
                                    text = generationChunk,
                                    modelUsed = "Streaming Network Inference..."
                                ),
                                onLineCopyTriggered = {}
                            )
                        }
                    }
                }
            }

            // Media attachment preview
            if (selectedImageUri != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .background(
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = selectedImageUri,
                            contentDescription = "Attached thumbnail",
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Photo Selected (MIME: Image/*)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { viewModel.selectImageUri(null) }) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Remove Photo",
                            tint = Color.Red
                        )
                    }
                }
            }

            // Chat Inputs & Controllers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Multimodal image upload button
                IconButton(
                    onClick = { imagePickerLauncher.launch("image/*") },
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.Outlined.PhotoCamera,
                        contentDescription = "Upload Photo",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Text Input Area
                TextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = {
                        Text(
                            text = "Ask M.Q.Live or chat... / بپرسید...",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp, max = 120.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                        disabledContainerColor = MaterialTheme.colorScheme.surface,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent
                    ),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Send Button with status feedback
                IconButton(
                    onClick = {
                        if (isGenerating) {
                            viewModel.stopGeneration()
                        } else {
                            if (textInput.trim().isNotEmpty() || selectedImageUri != null) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            }
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)
                            ),
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = if (isGenerating) Icons.Default.Stop else Icons.Default.Send,
                        contentDescription = "Action Button",
                        tint = ObsidianBlack
                    )
                }
            }
        }

        // Custom line-by-line Copy Dialog
        if (lineCopyMessage != null) {
            LineCopyDialog(
                message = lineCopyMessage!!,
                onDismiss = { lineCopyMessage = null }
            )
        }
    }
}

@Composable
fun MessageBubble(
    message: Message,
    onLineCopyTriggered: (Message) -> Unit
) {
    val context = LocalContext.current
    val isUser = message.sender == "user"
    val isDark = MaterialTheme.colorScheme.background == ObsidianBlack

    val alignment = if (isUser) Alignment.End else Alignment.Start
    val bubbleColor = if (isUser) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
    } else {
        MaterialTheme.colorScheme.surface
    }

    val borderColor = if (isUser) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
    } else {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = alignment
    ) {
        // Sender Metadata Name
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 4.dp, start = 8.dp, end = 8.dp)
        ) {
            Icon(
                imageVector = if (isUser) Icons.Default.Person else Icons.Default.AutoAwesome,
                contentDescription = null,
                modifier = Modifier.size(12.dp),
                tint = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (isUser) "You" else "M.Q.Live (${message.modelUsed ?: "Local GGUF"})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }

        // Main Card Bubble
        Card(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier
                .widthIn(max = 340.dp)
                .shadow(
                    elevation = if (isDark) 4.dp else 1.dp,
                    shape = RoundedCornerShape(16.dp),
                    ambientColor = MaterialTheme.colorScheme.primary
                )
                .border(1.dp, borderColor, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = bubbleColor)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Attached image rendering if multimodal
                if (message.imageUri != null) {
                    AsyncImage(
                        model = Uri.parse(message.imageUri),
                        contentDescription = "Message attachment",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .padding(bottom = 10.dp),
                        contentScale = ContentScale.Crop
                    )
                }

                // Render Perplexity-style web citations if available
                if (message.sourcesJson != null) {
                    SourcesCitationWidget(message.sourcesJson)
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Rich text formatter (parses code terminals vs. lines)
                FormattedMessageContent(
                    text = message.text,
                    onCopyRawTriggered = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("MQLive", message.text))
                        Toast.makeText(context, "Full text copied!", Toast.LENGTH_SHORT).show()
                    },
                    onLineCopyRequested = {
                        onLineCopyTriggered(message)
                    }
                )

                // Bottom timestamp indicator
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
                    Text(
                        text = sdf.format(Date(message.timestamp)),
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                }
            }
        }
    }
}

@Composable
fun FormattedMessageContent(
    text: String,
    onCopyRawTriggered: () -> Unit,
    onLineCopyRequested: () -> Unit
) {
    val context = LocalContext.current
    val isPersian = text.any { it in '\u0600'..'\u06FF' }
    val blockAlign = if (isPersian) TextAlign.Right else TextAlign.Left

    // Simple markdown code block parser
    val segments = remember(text) {
        val list = mutableListOf<TextSegment>()
        val codeBlockRegex = Regex("```([a-zA-Z]*)\\n([\\s\\S]*?)\\n```")
        var lastIndex = 0

        codeBlockRegex.findAll(text).forEach { match ->
            if (match.range.first > lastIndex) {
                list.add(TextSegment.Text(text.substring(lastIndex, match.range.first)))
            }
            val lang = match.groups[1]?.value ?: "code"
            val code = match.groups[2]?.value ?: ""
            list.add(TextSegment.Code(lang, code))
            lastIndex = match.range.last + 1
        }

        if (lastIndex < text.length) {
            list.add(TextSegment.Text(text.substring(lastIndex)))
        }

        if (list.isEmpty()) {
            list.add(TextSegment.Text(text))
        }
        list
    }

    Column {
        segments.forEach { segment ->
            when (segment) {
                is TextSegment.Text -> {
                    Text(
                        text = segment.content.trim(),
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = blockAlign,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                is TextSegment.Code -> {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = CyberSlate),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                                RoundedCornerShape(8.dp)
                            )
                    ) {
                        Column {
                            // Code block header panel
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(ObsidianBlack)
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Code,
                                        contentDescription = null,
                                        tint = NeonCyan,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = segment.language.uppercase(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = NeonCyan
                                    )
                                }
                                Row(
                                    modifier = Modifier.clickable {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("MQLiveCode", segment.code))
                                        Toast.makeText(context, "Code Copied!", Toast.LENGTH_SHORT).show()
                                    },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Outlined.ContentCopy,
                                        contentDescription = "Copy code",
                                        tint = Color.White.copy(alpha = 0.7f),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Copy Code",
                                        fontSize = 10.sp,
                                        color = Color.White.copy(alpha = 0.7f)
                                    )
                                }
                            }
                            // Code block content text
                            Text(
                                text = segment.code,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NeonCyan,
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxWidth(),
                                textAlign = TextAlign.Left
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }

        // Action controls toolbar
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Copy Full Text button
            Row(
                modifier = Modifier
                    .clickable { onCopyRawTriggered() }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.ContentCopy,
                    contentDescription = "Copy message",
                    modifier = Modifier.size(12.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Copy All",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            // Copy Line-by-Line button (Unique Luxury Requirement)
            Row(
                modifier = Modifier
                    .clickable { onLineCopyRequested() }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Layers,
                    contentDescription = "Copy line-by-line",
                    modifier = Modifier.size(12.dp),
                    tint = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Line Copy / کپی خط به خط",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SourcesCitationWidget(sourcesJsonStr: String) {
    val sources = remember(sourcesJsonStr) {
        val list = mutableListOf<SearchCitation>()
        try {
            val arr = JSONArray(sourcesJsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    SearchCitation(
                        title = obj.getString("title"),
                        url = obj.getString("url"),
                        snippet = obj.optString("snippet", "")
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        list
    }

    if (sources.isNotEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Language,
                    contentDescription = "Grounding",
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Sources Citations (Perplexity AI Grounding):",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                sources.forEachIndexed { idx, source ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CyberSlate),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(6.dp)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text(
                                text = "${idx + 1}. ${source.title}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = source.url.replace("https://", "").replace("www.", "").take(16) + "...",
                                fontSize = 8.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LineCopyDialog(
    message: Message,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lines = remember(message.text) {
        // Split text by lines, removing empty ones
        message.text.split("\n").filter { it.trim().isNotEmpty() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "Line-by-Line Copy Explorer",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Tap any row below to instantly copy that specific line.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        },
        text = {
            if (lines.isEmpty()) {
                Text("No copyable text found.")
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(lines) { line ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.surface,
                                    RoundedCornerShape(6.dp)
                                )
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("MQLiveLine", line))
                                    Toast.makeText(context, "Line Copied!", Toast.LENGTH_SHORT).show()
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = line,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                Icons.Outlined.ContentCopy,
                                contentDescription = "Copy this line",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = MaterialTheme.colorScheme.secondary)
            }
        },
        shape = RoundedCornerShape(12.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}

@Composable
fun EmptyStateWidget(settings: AppSettings) {
    val infiniteTransition = rememberInfiniteTransition(label = "EmptyPulse")
    val sizeScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Glowing pulsating neural circle
        Box(
            modifier = Modifier
                .size(100.dp)
                .shadow(16.dp, CircleShape, spotColor = NeonCyan)
                .background(
                    Brush.radialGradient(
                        colors = listOf(NeonCyan.copy(alpha = 0.3f), Color.Transparent)
                    ),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Welcome to M.Q.Live",
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Your elite AI workspace with online cloud neural hubs and local offline GGUF processing. Select any workspace parameters and start writing code or generating insights.",
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(30.dp))

        // Small decorative capsule displaying the active model status
        Box(
            modifier = Modifier
                .background(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                    RoundedCornerShape(16.dp)
                )
                .border(
                    1.dp,
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                    RoundedCornerShape(16.dp)
                )
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Active Engine: " + when (settings.activeModelType) {
                    "gemini" -> "Gemini Chat-3.5"
                    "groq" -> "Groq Mixtral-Ultra"
                    else -> "Offline Local GGUF Model"
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

sealed class TextSegment {
    data class Text(val content: String) : TextSegment()
    data class Code(val language: String, val code: String) : TextSegment()
}

data class SearchCitation(
    val title: String,
    val url: String,
    val snippet: String
)
