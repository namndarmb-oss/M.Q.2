package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Dark Theme Colors
val ObsidianBlack = Color(0xFF080710)
val CyberSlate = Color(0xFF131520)
val NeonCyan = Color(0xFF00F0FF)
val DeepSapphire = Color(0xFF0F4C81)
val NeuralViolet = Color(0xFF9F5CFF)
val TranslucentGlassDark = Color(0xAA1E293B)

// Premium Light Theme Colors
val AlabasterWhite = Color(0xFFF5F7FA)
val PureWhite = Color(0xFFFFFFFF)
val LuxuryNavy = Color(0xFF111827)
val SoftTeal = Color(0xFF0EA5E9)
val RoyalPurple = Color(0xFF6366F1)
val SlateGray = Color(0xFF6B7280)

// Backward compatibility or secondary tokens
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

