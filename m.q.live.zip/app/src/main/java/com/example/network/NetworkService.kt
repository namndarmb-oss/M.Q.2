package com.example.network

import android.content.Context
import android.net.Uri
import com.example.data.GgufModel
import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.io.InputStream
import java.util.concurrent.TimeUnit

// ==========================================
// Gemini API REST Structures
// ==========================================

data class GeminiRequest(
    val contents: List<GeminiContent>,
    val generationConfig: GeminiConfig? = null,
    val systemInstruction: GeminiContent? = null
)

data class GeminiContent(
    val role: String? = null, // "user" or "model"
    val parts: List<GeminiPart>
)

data class GeminiPart(
    val text: String? = null,
    val inlineData: GeminiInlineData? = null
)

data class GeminiInlineData(
    val mimeType: String,
    val data: String // Base64 representation
)

data class GeminiConfig(
    val temperature: Float? = null,
    val maxOutputTokens: Int? = null,
    val responseMimeType: String? = null
)

data class GeminiResponse(
    val candidates: List<GeminiCandidate>?
)

data class GeminiCandidate(
    val content: GeminiContent?
)

interface GeminiApi {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

// ==========================================
// Groq API OpenAI-Compatible Structures
// ==========================================

data class GroqRequest(
    val model: String,
    val messages: List<GroqMessage>,
    val temperature: Float? = 0.7f,
    val max_tokens: Int? = null
)

data class GroqMessage(
    val role: String, // "system", "user", "assistant"
    val content: String
)

data class GroqResponse(
    val id: String?,
    val choices: List<GroqChoice>?,
    val usage: GroqUsage?
)

data class GroqChoice(
    val message: GroqMessage?
)

data class GroqUsage(
    val prompt_tokens: Int?,
    val completion_tokens: Int?,
    val total_tokens: Int?
)

interface GroqApi {
    @POST("v1/chat/completions")
    suspend fun generateContent(
        @Header("Authorization") bearerToken: String,
        @Body request: GroqRequest
    ): GroqResponse
}

// ==========================================
// Retrofit Client Configurations
// ==========================================

object RetrofitClient {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val geminiRetrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val groqRetrofit = Retrofit.Builder()
        .baseUrl("https://api.groq.com/openai/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val geminiApi: GeminiApi by lazy { geminiRetrofit.create(GeminiApi::class.java) }
    val groqApi: GroqApi by lazy { groqRetrofit.create(GroqApi::class.java) }
}

// ==========================================
// GGUF Binary Parser
// ==========================================

object GgufParser {
    data class GgufHeader(
        val version: Int,
        val tensorCount: Int,
        val metadataCount: Int
    )

    fun parseHeader(context: Context, fileUri: Uri): GgufHeader {
        var inputStream: InputStream? = null
        try {
            inputStream = context.contentResolver.openInputStream(fileUri)
                ?: throw Exception("Could not open file stream")

            val headerBytes = ByteArray(24)
            val bytesRead = inputStream.read(headerBytes)
            if (bytesRead < 24) {
                throw Exception("File is too small to be a GGUF model.")
            }

            // GGUF Magic Header: 'G' 'G' 'U' 'F' (0x47, 0x47, 0x55, 0x46)
            if (headerBytes[0] != 'G'.toByte() || headerBytes[1] != 'G'.toByte() ||
                headerBytes[2] != 'U'.toByte() || headerBytes[3] != 'F'.toByte()) {
                throw Exception("Invalid model file type. GGUF header magic signature missing.")
            }

            // Read version (4 bytes, little-endian integer)
            val version = (headerBytes[4].toInt() and 0xFF) or
                    ((headerBytes[5].toInt() and 0xFF) shl 8) or
                    ((headerBytes[6].toInt() and 0xFF) shl 16) or
                    ((headerBytes[7].toInt() and 0xFF) shl 24)

            // Read tensor count (8 bytes, little-endian - parse first 4 bytes as Int)
            val tensorCount = (headerBytes[8].toInt() and 0xFF) or
                    ((headerBytes[9].toInt() and 0xFF) shl 8) or
                    ((headerBytes[10].toInt() and 0xFF) shl 16) or
                    ((headerBytes[11].toInt() and 0xFF) shl 24)

            // Read metadata count (8 bytes, little-endian - parse first 4 bytes at offset 16 as Int)
            val metadataCount = (headerBytes[16].toInt() and 0xFF) or
                    ((headerBytes[17].toInt() and 0xFF) shl 8) or
                    ((headerBytes[18].toInt() and 0xFF) shl 16) or
                    ((headerBytes[19].toInt() and 0xFF) shl 24)

            return GgufHeader(version, tensorCount, metadataCount)
        } finally {
            inputStream?.close()
        }
    }
}
