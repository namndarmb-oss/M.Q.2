package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val themeMode: String = "dark", // "dark", "light", "system"
    val activeModelType: String = "gemini", // "gemini", "groq", "offline"
    val geminiApiKey: String = "",
    val groqApiKey: String = "",
    val geminiModelName: String = "gemini-3.5-flash",
    val groqModelName: String = "llama-3.3-70b-versatile",
    val activeGgufId: Int? = null,
    val isVoiceEnabled: Boolean = true,
    val selectedVoice: String = "Kore" // "Kore", "Puck", "Fenrir"
)

@Entity(tableName = "chat_sessions")
data class ChatSession(
    @PrimaryKey val id: String,
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sessionId: String,
    val sender: String, // "user", "ai"
    val text: String,
    val imageUri: String? = null, // Path or URI to local image
    val timestamp: Long = System.currentTimeMillis(),
    val modelUsed: String? = null,
    val sourcesJson: String? = null // Perplexity-style search sources citation list
)

@Entity(tableName = "gguf_models")
data class GgufModel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fileName: String,
    val filePath: String,
    val fileSize: Long,
    val registerTime: Long = System.currentTimeMillis(),
    val version: Int = 3,
    val architecture: String = "llama",
    val tensorCount: Int = 0,
    val metadataKeysCount: Int = 0
)
